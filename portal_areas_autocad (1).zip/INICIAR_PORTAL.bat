@echo off
title Portal Web de Areas y PDF - AutoCAD
cd /d "%~dp0"

echo ============================================================
echo   INICIANDO PORTAL WEB DE AREAS Y PDF (AUTOCAD)
echo ============================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no esta instalado o no esta en el PATH.
    echo Descargalo desde https://www.python.org/downloads/ y marca "Add Python to PATH".
    pause
    exit /b 1
)

echo [1/3] Verificando e instalando dependencias...
python -m pip install -q -r requirements.txt
if errorlevel 1 (
    echo [ERROR] No se pudieron instalar las dependencias.
    pause
    exit /b 1
)

echo [2/3] Tu direccion local para compartir con el equipo es:
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /R /C:"IPv4"') do (
    echo    http://%%a:8000  (quita los espacios antes de la IP)
)
echo    En esta PC: http://localhost:8000
echo.

echo [3/3] Abriendo Google Chrome y arrancando el servidor...
echo       (NO cierres esta ventana mientras el equipo use el portal)
echo.
start "" "http://localhost:8000"
python -m uvicorn server:app --host 0.0.0.0 --port 8000
pause
